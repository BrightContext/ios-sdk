# Credits

My thanks to the following people and organisations, without whom this
library wouldn't be what it is today:

* Andrew Hannon
* Andrew W. Donoho
* Andy Warwick
* Ben Rimmington
* Blake Seely
* Gabriel Handford
* George MacKerron
* Greg Bolsinga
* Hager Hu
* Hiroshi Saito
* Jens Alfke
* Joerg Schwieder
* John Engelhart
* Konstantin Welke
* Lloyd Hilaiel
* Marc Lehmann
* Michael Papp
* Mike Monaco
* Robin Lu
* Sam Soffes
* Sean Scanlon
* The Adium Crew
* Tobias Höhmann
* Tod Karpinski
* Ullrich Schäfer
* Wolfgang Sourdeau
* aethereal
* boredzo
* dewvinci
* dmaclach
* jinksys
* lukef
* renerattur

(Please let me know if I've mistakenly omitted anyone.)
